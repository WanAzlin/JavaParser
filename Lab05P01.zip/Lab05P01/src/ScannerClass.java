/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tisha
 */
public class ScannerClass {
    private char currentChar = FrmMyCompiler.getTextTaProgram().charAt(0);
    private String currentSpelling;
    private int currentIndex = 0;
    private int currentKind;
    
    private void takeIt() {
        currentSpelling += currentChar;
        currentIndex++;
        if (currentIndex < 
              FrmMyCompiler.getTextTaProgram().length()) {
            currentChar = FrmMyCompiler.getTextTaProgram().charAt(currentIndex);           
        }
        else {
            currentChar = Character.UNASSIGNED;            
        }
    }
    
    public Token scan() {
        while (Character.isWhitespace(currentChar))  {
            takeIt(); 
        }

        currentSpelling = "";                               
        currentKind = scanToken();
        return new Token(currentKind, currentSpelling);
    }
    
    private int scanToken() {
        int state = 1; //Token.EOF
        if (currentIndex == FrmMyCompiler.getTextTaProgram().length())
            return Token.EOF; //state=1
        if (Character.isLetter(currentChar)) {
            takeIt();
            state = 2; //Token.IDENTIFIER
            while(Character.isLetterOrDigit(currentChar)) {
                takeIt();
            }
        }
        else {
            takeIt();
        }
        
        switch (state) {
            case 2:
                return Token.IDENTIFIER; //state=2
            default:
                return Token.UNKNOWN; //state=0
        }           
    }    
}

