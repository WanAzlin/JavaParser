/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */
public class Token {
    public int kind;
    public String spelling = "";
    
    Token(int kind, String spelling) {
        this.kind = kind;
        this.spelling = spelling;
    }
    
    public static final int VALID = 0;
    public static final int INVALID = 1;

    @Override
    public String toString() {
        if (kind == 0) {
            return "<valid, "+spelling+">";
        }
        return "<invalid, "+spelling+">";
    }    

    
}
